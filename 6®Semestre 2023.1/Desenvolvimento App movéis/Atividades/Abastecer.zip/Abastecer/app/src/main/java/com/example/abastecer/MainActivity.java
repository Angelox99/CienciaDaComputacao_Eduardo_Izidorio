package com.example.abastecer;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private TextView result;
    private EditText editGasolina, editAlcool;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        result = findViewById(R.id.Resultado);
        editGasolina = findViewById(R.id.Gasolina);
        editAlcool = findViewById(R.id.Alcool);
    }

    public void calcula(View v){
        String G = editGasolina.getText().toString();
        String A = editAlcool.getText().toString();
        double ValGasolina = Double.parseDouble(G);
        double ValAlcool = Double.parseDouble(A);

        if (G.equals("") || A.equals("")) {
            alertaDialog();
        }else{
            if ((ValAlcool / ValGasolina) < 0.7) {
                result.setText("Melhor Utilizar Gasolina");
            } else {
                result.setText("Melhor Utilizar Alcool");
            }
        }
    }

    public void alertaDialog (){
        //intanciar AlertDalog
        AlertDialog.Builder dialogo = new AlertDialog.Builder(this);
        //Título do Alerta
        dialogo.setTitle("Alerta");
        //Mensagem do Alerta
        dialogo.setMessage("Campo Obrigatório");
        //Configura Cacelamento
        dialogo.setCancelable(false); //Obriga o usuário a clicar nas opçoes o Alert
        //Configurar Ícone
        dialogo.setIcon(android.R.drawable.ic_dialog_alert);

        //dialogo.setNeutralButton("ok", null); // -----> Opções de ações SIM ou NÃO , OK etc.

        //Ação caso o usuári clique em positivo:
        dialogo.setPositiveButton("SIM", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //Ação caso seja clicado no botão "SIM"
                Toast.makeText(
                        getApplicationContext(),
                        "Executar a ação ao clicar POSITIVO",
                        Toast.LENGTH_LONG
                ).show();
            }
        });
        //Ação caso o usuário clique em negativo
        dialogo.setNegativeButton("NÃO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(
                        getApplicationContext(),
                        "Executar a ação ao clicar NEGATIVO",
                        Toast.LENGTH_LONG
                ).show();
            }
        });
        //Cria e exibe o Alerta!
        dialogo.create();
        dialogo.show();
    }
}