package com.example.rockpaperscissor;

import static com.example.rockpaperscissor.R.color.teal_700;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void escolhaUsuario(String escolha){
        int numero = new Random().nextInt(3);

        String[] opcoes = {"Rock", "Paper", "Scissors"};
        String opcaoApp = opcoes[numero];
        System.out.print(numero);

        ImageView imagemApp = findViewById(R.id.ImagemViewApp);

        String[] resultados = {"Vitoria", "Derrota", "Empate"};
        String resultado = "";

        switch(opcaoApp){
            case "Rock":
                imagemApp.setImageResource(R.drawable.pedra);
                if (escolha == "paper")
                    resultado = resultados[0];
                else if (escolha == "scissors")
                    resultado = resultados[1];
                else
                    resultado = resultados[2];
                break;
            case "Paper":
                imagemApp.setImageResource(R.drawable.papel);
                if(escolha == "paper")
                    resultado = resultados[2];
                else if(escolha == "scissors")
                    resultado = resultados[0];
                else
                    resultado = resultados[1];
                break;
            case "Scissors":
                imagemApp.setImageResource(R.drawable.tesoura);
                if(escolha == "paper")
                    resultado = resultados[1];
                else if(escolha == "scissors")
                    resultado = resultados[2];
                else
                    resultado = resultados[0];
                break;
            default:
                System.out.print(numero);
                break;
        }
        TextView resultadoF = findViewById(R.id.vencedor);
        switch (resultado){
            case "Vitoria":
                resultadoF.setTextColor(getColor(R.color.BlueViolet));
                break;
            case "Derrota":
                resultadoF.setTextColor(getColor(R.color.black));
                break;
            case "Empate":
                resultadoF.setTextColor(getColor(teal_700));

        }
        resultadoF.setText(resultado);
    }
    public void opcaoRock(View op){
        this.escolhaUsuario("Rock");
    }
    public void opcaoPaper(View op){
        this.escolhaUsuario("Paper");
    }
    public void opcaoScissors(View op){
        this.escolhaUsuario("Scissors");
    }
}
