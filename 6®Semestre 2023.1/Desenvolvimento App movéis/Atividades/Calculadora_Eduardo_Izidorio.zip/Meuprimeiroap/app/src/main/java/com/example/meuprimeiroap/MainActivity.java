package com.example.meuprimeiroap;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void OpSoma (View view){
        Button sum = findViewById(R.id.btAdicao);
        String operador = sum.getText().toString();
        TextView opSoma = findViewById(R.id.TextOperador);
        opSoma.setText(operador);
    }

    public void OpSubtr (View view){
        Button sub = findViewById(R.id.btSubtracao);
        String operador = sub.getText().toString();
        TextView opSubtr = findViewById(R.id.TextOperador);
        opSubtr.setText(operador);
    }

    public void OpMult (View view){
        Button mult = findViewById(R.id.btMultiplicacao);
        String operador = mult.getText().toString();
        TextView opMult = findViewById(R.id.TextOperador);
        opMult.setText(operador);
    }

    public void OpDiv (View view){
        Button Div = findViewById(R.id.btDivisao);
        String operador = Div.getText().toString();
        TextView opDiv = findViewById(R.id.TextOperador);
        opDiv.setText(operador);
    }

    public void Calcular(View view){
            EditText x = findViewById(R.id.EditTextx);
            String x1String = x.getText().toString();
            double xInteiro = Double.parseDouble(x1String);

            EditText y = findViewById(R.id.EditTexty);
            String x2String = y.getText().toString();
            double yInteiro = Double.parseDouble(x2String);

            TextView resultado = findViewById(R.id.Resultado);
            double r;

            TextView operacao = findViewById(R.id.TextOperador);
            String op = operacao.getText().toString();

            switch (op) {
                case "+":
                    r = xInteiro + yInteiro;
                    resultado.setText("" + r);
                    break;
                case "-":
                    r = xInteiro - yInteiro;
                    resultado.setText("" + r);
                    break;
                case "x":
                    r = xInteiro * yInteiro;
                    resultado.setText("" + r);
                    break;
                case "/":
                    try {
                        r = xInteiro / yInteiro;
                        resultado.setText("" + r);
                    } catch (ArithmeticException i) {
                        resultado.setText("Não divida por zero");
                    }
                    break;
                default:
                    resultado.setText("Escolha um Operador");
                    break;
            }
        }
    }