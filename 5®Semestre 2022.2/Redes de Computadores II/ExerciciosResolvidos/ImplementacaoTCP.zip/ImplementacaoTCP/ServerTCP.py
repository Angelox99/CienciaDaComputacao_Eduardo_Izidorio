import socket

HOST = 'localhost'  
PORT = 5000

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  #Trabalhando com IPv4 e usamos SOCK_STREAM para TCP
s.bind((HOST, PORT))  #invocamos o metodo bind e passamos o HOST e a PORT.
s.listen()  #Colocamos o servidor em modo de escuta.
print('Aguardando conexao de um cliente\n')  
conn, ender = s.accept()  #Criamos o metodo para aceitar a conexao.

print('Conectado em', ender) 

while True:  #Criamos um loop. Onde criamos uma variavel para receber os dados.
    data = conn.recv(1024)
    if not data:  #quando nao tiver mas nada fechamos a conexao.
        print('\nFechando a conexao')
        conn.close()
        break
    conn.sendall(data)
