import socket

HOST = '192.168.0.42'
PORT = 5000  

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  #Trabalhando com IPv4 e TCP.
s.connect((HOST, PORT))  #pedir para conectar ao servidor.
s.sendall(str.encode("RECEBA!"))  #envio dos dados.
data = s.recv(1024)  #data recebe os dados ecoados no servidor.

print('Mensagem ecoada: ', data.decode())  #imprimir a mensagem ecoada.
