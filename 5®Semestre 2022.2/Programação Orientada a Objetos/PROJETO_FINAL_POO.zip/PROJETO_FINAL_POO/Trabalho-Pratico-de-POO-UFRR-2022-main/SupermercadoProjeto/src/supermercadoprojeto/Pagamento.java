package supermercadoprojeto;

public class Pagamento {
    float valorPago;
    
//CONSTRUTOR
    public Pagamento(float valorPago){   
        this.valorPago = valorPago;
    }
    
//METODO ESPECIAL    
    public float getValorPago(){        
        return valorPago;
    }
}
