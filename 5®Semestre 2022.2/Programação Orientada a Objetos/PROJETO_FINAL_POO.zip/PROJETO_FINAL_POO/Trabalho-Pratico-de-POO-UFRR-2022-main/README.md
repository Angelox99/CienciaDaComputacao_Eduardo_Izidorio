# POO_Projeto_Final_2022.2_UFRR
Supermercado NEXUS - CODIFICAÇÃO E SIMULAÇÕES 

Este repositório é referente ao projeto final da disciplina Programação orientada a objetos (DCC305) e seus resultados desenvolvidos pelos alunos Eduardo Henrique Izidorio, Gabriel Peixoto, Marcia Gabrielle e Shelly da Costa.
# Softwares Utilizados:
Apache Netbeans IDE - Usado para criação, testes e obtenção de resultados. Versão Utilizada: 12.5
# Linguagem de Programação:
JAVA - Versão Utilizada: JDK 19
