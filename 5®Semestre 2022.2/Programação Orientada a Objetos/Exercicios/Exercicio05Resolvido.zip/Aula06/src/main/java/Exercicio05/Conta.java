// Questão 01 - criar uma classe Conta, que possua um saldo os métodos para pegar saldo, depositar e sacar.

package Exercicio05;

public class Conta {
    protected double saldo;
    
    public double getSaldo(){
        return this.saldo;
    }
    //Método para depositar dinheiro.
    public void deposita(double valor){
        this.saldo += valor;  // this.saldo = this.saldo + valor;
    } 
    //Método para sacar dinheiro.
    public void saca(double valor){
        this.saldo -= valor;  // this.asldo = this.saldo - valor;
    }
    // Questão 02 - atualiza essa conta de acordo com uma taxa percentual fornecida.
    
    //Método para atualizar a taxa percentual fonercida.
    public void atualiza(double v){
        this.saldo -= v;
    }
}
