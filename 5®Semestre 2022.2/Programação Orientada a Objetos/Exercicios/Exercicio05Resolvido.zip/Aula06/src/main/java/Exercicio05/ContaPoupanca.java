// Quetão 03 - Subclasses da Classe Conta.

package Exercicio05;

public class ContaPoupanca extends Conta {
    public void atualiza(double v){
        super.atualiza(3 * v);     // Questão 08
    }
    public void deposita(double valor){
        this.saldo += valor;
    }
}
