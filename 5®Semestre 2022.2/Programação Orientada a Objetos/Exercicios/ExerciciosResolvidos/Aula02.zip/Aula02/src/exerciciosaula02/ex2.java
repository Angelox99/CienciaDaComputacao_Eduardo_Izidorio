package exerciciosaula02;

public class ex2 {
	public static void main(String[] args) {
		int x = 1;
		int y = 1000;
		int soma = (x + y) * ((y - x + 1) /2);
		System.out.println(soma);
		
	}

}
