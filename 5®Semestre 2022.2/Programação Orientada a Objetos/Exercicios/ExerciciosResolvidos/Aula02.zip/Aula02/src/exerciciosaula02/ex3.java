package exerciciosaula02;

public class ex3 {
	public static void main(String[] args) {
		System.out.println("Multiplos de 3, entre 1 a 100");
		for(int i = 1; i <= 100; i++) {
			if(i % 3 == 0) {
				System.out.println(i);
			}
		}
	}

}
