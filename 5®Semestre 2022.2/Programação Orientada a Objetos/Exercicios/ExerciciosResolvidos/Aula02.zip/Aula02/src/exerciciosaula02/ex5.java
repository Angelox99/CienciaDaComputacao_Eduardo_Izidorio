package exerciciosaula02;

public class ex5 {
	public static void main(String[] args) {
		System.out.println("Fatoriais de 1 a 10");
		for(int i = 1, fatorial = 1; i <= 10;) {
			//fatorial = i * fatorial;
			System.out.println(++i + "! = " + (fatorial *= i));
		}
		}
}
