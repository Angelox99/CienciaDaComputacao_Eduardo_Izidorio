package exerciciosaula02;

public class ex4 {
	public static void main(String[] args) {
		System.out.println("Fatoriais de 1 a 10");
		int fatorial = 1;
		for(int n = 1; n <= 10; n++) {
			fatorial = n * fatorial;
			System.out.println(fatorial + " ");
		}
	}

}
