package exerciciosaula02;

public class ex6 {
	public static void main(String[] args) {
		System.out.println("Fatoriais de 1 a 20/30/40");
		for(long i = 1, fatorial = 1; i <= 20;) {
			System.out.println(++i + "! = " + (fatorial *= i));
		}
	}
	//a variavel do tipo int pode suportar ate certa quantidade de numeros, logo
	//quando passa desse máximo o java imprime valores errados.
	//ja usando a variavel long armazena inteiros de tamanho maior que o tipo int,
	//mas tambem vai ate certa quantidade ate dar o erro dos valores errados.
}
