package exerciciosaula02;

public class ex1 {
	public static void main(String[] args) {
		System.out.println("Valores de 150 a 300");
			for(int i = 150; i <= 300; i++) {
				System.out.println(i);
			}
	}
}
