package exerciciosaula02;

public class ex7 {
	public static void main(String[] args) {
		System.out.println("Calculando Fibonacci");
		int n, i = 1, j = 0;
		n = i + j;
		while(n <= 100) {
			System.out.println(n);
			j = i;
			i = n;
			n = i + j;
		}
		
	}

}
