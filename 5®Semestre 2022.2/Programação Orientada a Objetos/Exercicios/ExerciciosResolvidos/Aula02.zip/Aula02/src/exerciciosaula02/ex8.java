package exerciciosaula02;

public class ex8 {
	public static void main(String[] args) {
        System.out.println("Valor qualquer variavel X");
		int x = 15;
        while(x != 1){
            if( x % 2 == 0){
                x = x / 2;
            } else {
                x = 3 * x + 1;
            }            
            System.out.print(" -> " + x);
        }
    }
}
