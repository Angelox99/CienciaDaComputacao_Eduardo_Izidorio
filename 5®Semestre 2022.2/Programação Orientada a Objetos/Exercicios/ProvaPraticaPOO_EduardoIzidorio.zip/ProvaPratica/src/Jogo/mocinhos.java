
package Jogo;

public class mocinhos extends personagem {
    
    public mocinhos(String n, int energia, int vida){
        setNome(n);
        setEnergia(energia);
        setVida(vida);
    }
    
    public void Imprime() {
        System.out.println("Hero is Name: " + nome);
        System.out.println("Energia: " + energia);
        System.out.println("Vida: " + vida);
        System.out.println("\n\n");
    }

    public void conversar(Jogo.personagem p, Jogo.personagem v) {
        if(v.energia < 3){
            System.out.println("Ja ouviu falar do Let Me Solo Her, entao na morte ira conhecer...");
        }
    }
    
    void alimentar(){
        energia += 2;
    }
    
}
