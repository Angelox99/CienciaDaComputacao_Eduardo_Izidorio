/*-----------------------------------------------------------
* Prova Pratica de POO
* Autor: Eduardo Henrique de Almeida Izidorio
* Matricula: 2020000315
* -----------------------------------------------------------*/
package Jogo;

import static Jogo.personagem.lutar;

public class Confronto {
    public static void main(String[] args) {
        personagem p = new mocinhos("Sung Jun Woo", 10, 7);
        personagem v = new viloes("Monarca Da Destruicao", 10, 7);
        
        p.Imprime();
        v.Imprime();
        
        while(p.vida != 0 && v.vida != 0){
        
         lutar(p, v);
         p.Imprime();
         v.Imprime();
         p.conversar(p, v);
         v.conversar(p, v);
        }
        
        if(p.vida == 0){
            System.out.println("------ The Hero is DEAD ------");
        } else {
            System.out.println("------ The villain is DEAD ------");
        }
    }
    
}
