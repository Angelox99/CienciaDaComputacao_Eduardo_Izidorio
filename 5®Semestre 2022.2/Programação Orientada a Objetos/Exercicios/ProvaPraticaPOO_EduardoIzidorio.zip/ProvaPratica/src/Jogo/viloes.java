
package Jogo;

public class viloes extends personagem {
    
    public viloes(String n, int energia, int vida){
        setNome(n);
        setEnergia(energia);
        setVida(vida);
    }
    
    public void conversar(personagem p, personagem v){
        if (p.energia < 3){
            System.out.println("Voce esta fraco, " + p.nome + ", lhe falta odio para me derrotar...");
        }
    }
    
    public void Imprime() {
        System.out.println("Villain is Name: " + nome);
        System.out.println("Energia: " + energia);
        System.out.println("Vida: " + vida);
        System.out.println("\n\n");
    }
    
}
