
package Jogo;

class EnergiaTotal extends Exception {
    
    EnergiaTotal(int valor){
        super("\nEnergia esta Cheia");
    }
}
