// Questão 04 - classe com método main e instancie essas classes, atualize-as e veja o resultado.

package Exercicio05;

public class Contas {
    public static void main(String[] args) {
        //Questao 05
        //Conta c = new Conta();
        //temos a utilidade de herdar os metodos e atribuir da conta para as classes filhas.
        Conta cc = new ContaCorrente();
        Conta cp = new ContaPoupanca();
        
       // c.deposita(1000);
        cc.deposita(1000);
        cp.deposita(1000);
        
        
        /* Parte da questão 04
        c.taxa(0.01);
        cc.taxa(0.01);
        cp.taxa(0.01);
        */
        
        // Questão 07 - criar algumas contas e rodá-las
        AtualizadorDeContas adc = new AtualizadorDeContas(0.01);
        /*
        adc.roda(c);
        adc.roda(cc);
        adc.roda(cp);
        */
        
        System.out.println("\nCriando um Banco com 3 contas");
        Banco banco = new Banco(3);
        //banco.adiciona(c);
        banco.adiciona(cc);
        banco.adiciona(cp);
        
        for(int i = 0; i < banco.pegaTotalDeContas(); i++){
            System.out.println("\nFuncionario de número: " + (i+1));
            System.out.println("Saldo: " + banco.pegaConta(i).getSaldo());
            adc.roda(banco.pegaConta(i));
        }
        System.out.println("");
        System.out.println("Saldo Total: " + adc.getSaldoTotal());
        //System.out.println("Saldo Conta: " + c.getSaldo());
        System.out.println("Saldo Conta Corrente: " + cc.getSaldo());
        System.out.println("Saldo Conta Poupança: " + cp.getSaldo());
    }
    
}
