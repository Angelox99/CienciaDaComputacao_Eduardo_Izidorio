// Questão 01 - criar uma classe Conta, que possua um saldo os métodos para pegar saldo, depositar e sacar.

package Exercicio05;
//1. É interessante porque podemos usar a classe abstrata quando não faz sentido
//termos instâncias de determinadas classes. E quando fazemos isso o main deixa de instaciar Conta.

public abstract class Conta {
    protected double saldo;
    
    public double getSaldo(){
        return this.saldo;
    }
    //Método para depositar dinheiro.
    public void deposita(double valor){
        this.saldo += valor;  // this.saldo = this.saldo + valor;
    } 
    //Método para sacar dinheiro.
    public void saca(double valor){
        this.saldo -= valor;  // this.asldo = this.saldo - valor;
    }
    // Questão 02 - atualiza essa conta de acordo com uma taxa percentual fornecida.
    
    /*Método para atualizar a taxa percentual fonercida.
    public void atualiza(double v){
        this.saldo -= v;
    }*/
    
    public abstract void atualiza(double taxaSelic); 
}
