    // Questão 06 - criar uma classe que seja responsável por fazer a atualização de todas as contas 
//bancárias e gerar um relatório com o saldo anterior e saldo novo de cada uma das contas.

package Exercicio05;

public class AtualizadorDeContas {
    private double saldoTotal = 0;
    private double selic;
    
    public AtualizadorDeContas(double selic) {
        this.selic = selic;
    }
    /* Questão 09
    Não. A utilidade da herança para criar super classes bem gerais, e fazer as alterações somente em locais específicos.
    Como é uma situação específica, fazemos um override do método atualiza da classe ContaInvestimento.*/
    
    public void roda(Conta c){
        System.out.println("Antes da Atualização: "+ c.getSaldo());
        c.atualiza(this.selic);
        System.out.println("Depois da Atualização: "+ c.getSaldo());
        this.saldoTotal += c.getSaldo();
    }
    
    public double getSaldoTotal(){
        return saldoTotal;
    }
}
