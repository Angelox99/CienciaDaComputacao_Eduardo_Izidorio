// Quetão 03 - Subclasses da Classe Conta.

package Exercicio05;

public class ContaCorrente extends Conta{
    
    /*public void atualiza(double v){
        super.atualiza(2 * v);     // Questão 08
    }*/
    public void deposita(double valor){
        this.saldo += valor - 0.10;
    }

    public void atualiza(double taxaSelic) {
        this.saldo += (2*taxaSelic);
    }
}
