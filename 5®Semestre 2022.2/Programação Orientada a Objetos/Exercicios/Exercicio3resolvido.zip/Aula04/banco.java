
package Aula04;

public class banco {
public static void main(String[] args) throws Exception 
    {
        //Funcionarios instanciados
        funcionario F1;
        funcionario F2;
        F1 = new funcionario();
        F2 = new funcionario();

        //Funcionario 1
        F1.nome = "Menezes";
        F1.RG = "894766-9";
        F1.DatadeEntrada.dia = 15;
        F1.DatadeEntrada.mes = 12;
        F1.DatadeEntrada.ano = 1990;
        F1.departamento = "Administração";
        F1.salario = 2700;
        
        //Funicionario 2
        F2.nome = "Clotiude";
        F2.RG = "367476-0";
        F2.DatadeEntrada.dia = 20;
        F2.DatadeEntrada.mes = 12;
        F2.DatadeEntrada.ano = 1980;
        F2.departamento = "Banco de Dados";
        F2.salario = 2700;
        
        //Criando empresa
        Empresa E1 = new Empresa();
        E1.nome= "DODO CONCEITOS";
        E1.cnpj= "156482315";
        E1.telefone= "4002-8922";

        //Adiciona Funcionario na empresa
        E1.adiciona(F1);
        E1.adiciona(F2);

        //funcionario + salario = empresa adiciona
        for(int i=0;i<8;i++)
        {
            funcionario f = new funcionario();
            E1.adiciona(f);
        }

        //Mostra os Funcionarios da empresa
        System.out.println("-----------------------------------");
        E1.mostraEmpresa();
        System.out.println("-----------------------------------");
        E1.mostraFuncionarios();
        System.out.println("-----------------------------------");
        E1.checkFuncionario();
        
    }
}    

