//Nome: Eduardo Henrique de Almeida Izidorio 
//Matricula: 2020000315
//EXERCICIO 5

package ExercicioAula05;

public class BancoFuncionarios {
    public static void main (String[] args){
        
    //QUANDO ADICIONAMOS OS MODIFICADORES DE VISIBILIDADE(PRIVATE) NOS ATRIBUTOS
    //AUTOMATICAMENTE RESTRIGE TOTALMMENTE O ACESSO DOS ATRIBUTOS DIRETAMENTE
        
    //Criacao do primeiro funcionario sem informar diretamente na criaçao do objeto    
    
        Funcionario f1 = new Funcionario();    
        
        f1.setDepartamento("TI");
        f1.setRg("345678");
        f1.setSalario(6000);
        f1.mostra();
    //Criacao do segundo funcionario informando logo o nome do funcionario no objeto
        
        Funcionario f2 = new Funcionario("Kira");  
        
        f2.setDepartamento("RH");
        f2.setRg("345678");
        f2.setSalario(3000);
        f2.mostra();

    
      
    //Criacao de uma empresa
    
        Empresa e1 = new Empresa();
        e1.setNome("Yoshida");
        e1.setCnpj("49876543");
        
     // adiciona os funcionarios na empresa
        e1.add(f1);
        e1.add(f2);
    
        
    for(int i=0;i<8;i++) {
            Funcionario f = new Funcionario();
            e1.add(f);
        }    
    
    
    
    /*
        System.out.println("---------------------------------");
        System.out.println(e1.empregados[0].nome);
        System.out.println(e1.empregados[1].nome);
        
        
        
        Foi criado um metodo 'mostra' para imprimir todos os atributos 
        do funcionarios e não sera necessario criar um monte de println
        
        System.out.println("Nome: "+f1.nome);
        System.out.println("Departamento: " + f1.departamento);
        System.out.println("RG: " +f1.rg);
        System.out.println("Salario: "+f1.salario);
        System.out.println("Data de entrada no Banco: " +f1.dataEntrada);
        System.out.println("Ganho Anual: "+f1.calculaGanhaAnual());
        */
        
        //f1.mostra(); antigo metodo para mostrar os atributos dos funcionario
        //f2.mostra();
        
    //NOVO METODO PARA MOSTRAR OS ATRIBUTOS DA EMPRESA E DOS FUNCIONARIO
    
        System.out.println("-----------------------------------");
        e1.mostraEmpresa();
        System.out.println("-----------------------------------");
        e1.mostraFuncionarios();
        System.out.println("-----------------------------------");
        e1.checkFuncionario();
    }
}
