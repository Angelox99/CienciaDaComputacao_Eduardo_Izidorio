
package ExercicioAula05;

public class Data {
    private int dia, mes, ano;  

    public void formatData(){
        
        System.out.println(dia +"/"+mes+"/"+ano);
    }
}
