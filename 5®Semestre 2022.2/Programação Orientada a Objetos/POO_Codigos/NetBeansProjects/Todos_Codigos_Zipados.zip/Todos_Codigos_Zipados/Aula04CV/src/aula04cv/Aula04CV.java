
package aula04cv;

public class Aula04CV {

    public static void main(String[] args) {
        Caneta c1 = new Caneta();
    }
    
}
