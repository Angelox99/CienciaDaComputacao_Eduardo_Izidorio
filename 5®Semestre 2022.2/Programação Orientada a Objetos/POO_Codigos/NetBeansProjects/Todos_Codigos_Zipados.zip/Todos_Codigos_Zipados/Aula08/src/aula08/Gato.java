
package aula08;

public class Gato {
    
}
