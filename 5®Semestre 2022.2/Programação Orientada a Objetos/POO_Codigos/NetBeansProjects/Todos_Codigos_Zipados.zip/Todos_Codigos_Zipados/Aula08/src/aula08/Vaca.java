
package aula08;

public class Vaca {
    
}
