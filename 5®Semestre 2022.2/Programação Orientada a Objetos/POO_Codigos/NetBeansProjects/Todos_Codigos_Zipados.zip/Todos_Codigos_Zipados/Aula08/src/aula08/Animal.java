
package aula08;

public class Animal {
    protected String nome;
    
}
