
package aula05exemplo;

public class Aula05exemplo {

    public static void main(String[] args) {
    }
    
}
