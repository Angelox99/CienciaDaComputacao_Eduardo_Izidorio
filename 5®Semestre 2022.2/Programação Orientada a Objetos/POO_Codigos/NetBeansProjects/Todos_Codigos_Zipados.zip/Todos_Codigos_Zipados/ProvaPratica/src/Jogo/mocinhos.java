
package Jogo;

public class mocinhos extends personagem {
    
    public mocinhos(String n, int energia, int vida){
        setNome(n);
        setEnergia(energia);
        setVida(vida);
    }
    
    public void Imprime() {
        System.out.println("Nome Heroi: " + nome);
        System.out.println("Energia: " + energia);
        System.out.println("Vida: " + vida);
        System.out.println("\n");
    }

    public void conversar(Jogo.personagem p, Jogo.personagem v) {
        if(v.energia < 3){
            System.out.println("O bem sempre vencera\n");
        }
    }
    
    void alimentar(){
        energia += 2;
    }
    
}
