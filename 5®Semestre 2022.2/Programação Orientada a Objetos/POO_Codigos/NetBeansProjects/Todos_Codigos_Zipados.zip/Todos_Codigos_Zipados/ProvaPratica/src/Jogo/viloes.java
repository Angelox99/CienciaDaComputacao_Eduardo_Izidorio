
package Jogo;

public class viloes extends personagem {
    
    public viloes(String n, int energia, int vida){
        setNome(n);
        setEnergia(energia);
        setVida(vida);
    }
    
    public void conversar(personagem p, personagem v){
        if (p.energia < 3){
            System.out.println("Hasta la vista, baby\n");
        }
    }
    
    public void Imprime() {
        System.out.println("Nome Vilao: " + nome);
        System.out.println("Energia: " + energia);
        System.out.println("Vida: " + vida);
        System.out.println("\n");
    }
    
}
