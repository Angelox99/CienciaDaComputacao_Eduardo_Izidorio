/*-----------------------------------------------------------
* Prova Pratica de POO
* Autor(a): Shelly da Costa Leal
* Matricula: 2020001671
* -----------------------------------------------------------*/
package Jogo;

import static Jogo.personagem.lutar;

public class Duelo {
    public static void main(String[] args) {
        personagem p = new mocinhos("Harry Potter", 10, 7);
        personagem v = new viloes("Voldemort", 10, 7);
        
        p.Imprime();
        v.Imprime();
        
        while(p.vida != 0 && v.vida != 0){
        
         lutar(p, v);
         p.Imprime();
         v.Imprime();
         p.conversar(p, v);
         v.conversar(p, v);
        }
        
        if(p.vida == 0){
            System.out.println("------ No ceu tem pao??? ------");
        } else {
            System.out.println("------ Expecto Patrono ------");
        }
    }
    
}
