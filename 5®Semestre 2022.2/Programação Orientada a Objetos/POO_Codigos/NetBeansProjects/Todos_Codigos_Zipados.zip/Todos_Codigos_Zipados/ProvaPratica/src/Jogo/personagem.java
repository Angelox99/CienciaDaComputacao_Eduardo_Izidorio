
package Jogo;

import java.util.Random;

public abstract class personagem {
    protected String nome;
    protected int energia;
    protected int vida;
    
    // Construtor
    
    public void personagem (String n) {
        this.nome = n;
        this.energia = 10;
        this.vida = 7;
    }
    
    int sorte(){
        Random R = new Random();
        int n= R.nextInt(6);
        System.out.println(n);
        return n;
    }
    
    // Metodos Especiais
    
    public String getNome(){
        return nome;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public int getEnergia(){
        return energia;
    }
    
    public void setEnergia(int energia){
        this.energia = energia;
    }
    
    public int getVida(){
        return vida;
    }
    
    public void setVida(int vida){
        this.vida = vida;
    }
    
    
    // Metodos
    
    public void incremento() throws EnergiaTotal{
        if (this.energia != 10){
            this.energia += 1;
        } else{
            throw new EnergiaTotal(energia);
        }
        }
    
    public void decremento() throws EnergiaTotal{
        if (this.energia != 0){
            this.energia -= 1;
        } if (this.energia == 0){
            this.vida -= 1;
        } else{
            throw new EnergiaTotal(energia);
        }
    }
    
    public abstract void Imprime();
    public abstract void conversar(personagem p, personagem v);
    
    
    static void lutar(personagem p, personagem v ){

        int a = p.sorte();
        int b = v.sorte();
        
        if(a>b){
        try{    
          p.incremento();
          } catch(EnergiaTotal exception){
          System.out.println(exception.getMessage());
          }
        try{
          v.decremento();
          } catch(EnergiaTotal exception){
          System.out.println(exception.getMessage());
          }
          System.out.println(p.nome+" venceu");
        }
        
        if(b>a){
        try{
          v.incremento();
          } catch(EnergiaTotal exception){
          System.out.println(exception.getMessage());
          }
        try{
          p.decremento();
          } catch(EnergiaTotal exception){
          System.out.println(exception.getMessage());
          }
          System.out.println(v.nome+" venceu");
        }
        if(b==a){
        try{
          p.decremento();
          } catch(EnergiaTotal exception){
          System.out.println(exception.getMessage());
          }
        try{
          v.decremento();
          } catch(EnergiaTotal exception){
          System.out.println(exception.getMessage());
          }
          System.out.println(p.nome+" empatou com "+v.nome);
        } 
    }
}