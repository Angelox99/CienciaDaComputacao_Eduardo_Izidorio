
public abstract class Conta {
    protected int saldo;
    private String nome;
    protected int numero;

    public void setNumero(int numero){
        this.numero=numero;
    }

    public int getNumero(){
        return this.numero;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getSaldo(){
        return this.saldo;
    }
    
 
    abstract public void Deposita(int valor);
    public abstract void Atualiza(double taxa);
    
    public void Saca(int valor){
        if(valor<this.saldo){
        this.saldo=-valor;
        }
        else{
            System.out.println("Não é possivel sacar essa quantia. Saldo disponivel: "+this.saldo);
        }
    }
}
