
class ContaCorrente extends Conta {
    public void Atualiza(double taxa) {
        this.saldo += this.saldo*(taxa*2);
    }

    public void Deposita(int valor) {
        this.saldo += valor - 0.10;
    }
}
