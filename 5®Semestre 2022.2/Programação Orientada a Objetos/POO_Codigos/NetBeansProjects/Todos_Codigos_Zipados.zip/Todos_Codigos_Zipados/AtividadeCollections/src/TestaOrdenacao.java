import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class TestaOrdenacao {
    public static void main(String[] args) {

    ContaPoupança cp1= new ContaPoupança();
    ContaPoupança cp2= new ContaPoupança();
    ContaPoupança cp3= new ContaPoupança();

    cp1.Deposita(2000);
    cp1.setNome("Brasil");
    cp2.Deposita(4500);
    cp2.setNome("Peru");
    cp3.Deposita(2400);
    cp3.setNome("Japa");

    List<ContaPoupança > contas = new LinkedList<ContaPoupança>(); 

    /* Na mudança de ArrayList para Linkedlist a unica diferença,
     foi a necessidade da implementação da biblioteca LinkedList.*/

    contas.add(cp1);
    contas.add(cp2);
    contas.add(cp3);

    // Saídas 

    //SAÍDA INICIAL
    System.out.println(contas);

    //TAMANHO DA LISTA
    System.out.println(contas.size());

    //ORDENAÇÃO POR SALDO
    Collections.sort(contas);
    System.out.println(contas);
    System.out.println("\n");

    //ORDENAÇÃO REVERSA
    Collections.reverse(contas);
    System.out.println(contas);
    System.out.println("\n");

    //ORDENAÇÃO EMBARALHADA
    Collections.shuffle(contas);
    System.out.println(contas);
    System.out.println("\n");

    //ORDENAÇÃO POR SALDOS ROTACIONADOS --- USASSE O VALOR DE POSIÇÕES PARA A TROCA
    Collections.rotate(contas, 1);
    System.out.println(contas);
    System.out.println("\n");

 }
}
