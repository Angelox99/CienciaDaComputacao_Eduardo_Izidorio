
class ContaPoupança extends Conta implements Comparable<ContaPoupança> {
    public int compareTo(ContaPoupança outra){
        return (this.getSaldo() - outra.getSaldo());
    }

    public String toString() {
        return "Conta: " + this.getNome() + " Saldo: " + this.getSaldo();
    }

    public void Atualiza(double taxa) {
        this.saldo += this.saldo*(taxa*3);
    }

    public void Deposita(int valor){
        this.saldo=+valor;
    }   
}
