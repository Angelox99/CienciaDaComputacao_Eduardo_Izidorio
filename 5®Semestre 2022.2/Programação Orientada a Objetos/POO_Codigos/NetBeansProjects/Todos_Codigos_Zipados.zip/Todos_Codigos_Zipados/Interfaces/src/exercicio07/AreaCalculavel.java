
package exercicio07;

public interface AreaCalculavel {
    double calculaArea();
}
