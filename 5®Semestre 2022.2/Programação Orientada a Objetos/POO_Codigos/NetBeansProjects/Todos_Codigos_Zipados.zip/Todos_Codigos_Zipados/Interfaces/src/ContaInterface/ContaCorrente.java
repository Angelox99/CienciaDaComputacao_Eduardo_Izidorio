
package ContaInterface;

public class ContaCorrente implements Conta, Tributavel {
    private double saldo;
    
    public void deposita(double valor){
        this.saldo += valor;
    }

    public void atualiza(double taxaSelic) {
        this.saldo += this.saldo * taxaSelic * 2;
    }

    public double getSaldo() {
        return this.saldo;
    }
    
    public void saca(double valor) {
        this.saldo -= valor;
    }

    public double calculaTributos() {
        return this.saldo * 0.01;
    }
}
