
package ContaInterface;

public class ContaPoupanca implements Conta {
    private double saldo;
    
    public void deposita (double valor){
    }

    public void atualiza(double taxaSelic) {
        this.saldo += this.saldo * taxaSelic * 3;
    }

    public double getSaldo() {
        return this.saldo;
    }

    public void saca(double valor) {
        this.saldo -= valor;
    }
}
