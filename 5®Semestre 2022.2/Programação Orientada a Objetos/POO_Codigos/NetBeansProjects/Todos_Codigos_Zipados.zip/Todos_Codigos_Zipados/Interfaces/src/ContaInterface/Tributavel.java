
package ContaInterface;

public interface Tributavel {
    double calculaTributos();
    
}
