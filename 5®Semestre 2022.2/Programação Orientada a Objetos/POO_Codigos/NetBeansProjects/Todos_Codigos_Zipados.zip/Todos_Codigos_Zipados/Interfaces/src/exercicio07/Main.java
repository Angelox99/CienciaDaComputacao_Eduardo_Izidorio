
package exercicio07;

public class Main {
    public static void main(String[] args) {
        Quadrado q = new Quadrado(2);
        Retangulo r = new Retangulo(4,8);
        
        System.out.println(q.calculaArea());
        System.out.println(r.calculaArea());
    }
}
