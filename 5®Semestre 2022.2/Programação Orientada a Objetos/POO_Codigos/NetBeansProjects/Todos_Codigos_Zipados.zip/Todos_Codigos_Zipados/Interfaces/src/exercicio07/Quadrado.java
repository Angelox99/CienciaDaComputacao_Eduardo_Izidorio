
package exercicio07;

public class Quadrado implements AreaCalculavel{
    private int lado;
    
    public Quadrado(int lado) {
        this.lado = lado;
    }
    
    public double calculaArea() {
        return this.lado * this.lado;
    }
    
    public double getLado(){
        return lado;
    }
    
    public void setLado(int lado){
        this.lado = lado;
    }
}
