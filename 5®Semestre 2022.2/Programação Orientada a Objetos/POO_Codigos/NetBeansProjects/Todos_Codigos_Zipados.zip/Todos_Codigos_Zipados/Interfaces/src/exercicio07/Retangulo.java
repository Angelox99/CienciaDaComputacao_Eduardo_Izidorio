 
package exercicio07;

public class Retangulo implements AreaCalculavel {
     private int largura;
    private int altura;
    
    public Retangulo(int altura, int largura){
        this.largura = largura;
        this.altura = altura;
    }
    
    public double calculaArea() {
        return largura * altura;
    }
    
    public double getLargura(){
        return this.largura;
    }
    
    public void setBase(int largura){
        this.largura = largura;
    }
    
    public double getAltura(){
        return this.altura;
    }
    
    public void setAltura(int altura){
        this.altura = altura;
    }
}
