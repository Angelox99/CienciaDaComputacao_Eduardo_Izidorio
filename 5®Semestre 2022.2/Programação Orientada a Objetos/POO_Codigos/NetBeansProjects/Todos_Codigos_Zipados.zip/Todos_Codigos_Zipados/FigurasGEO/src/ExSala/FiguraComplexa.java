
package ExSala;

public class FiguraComplexa {
    
}
