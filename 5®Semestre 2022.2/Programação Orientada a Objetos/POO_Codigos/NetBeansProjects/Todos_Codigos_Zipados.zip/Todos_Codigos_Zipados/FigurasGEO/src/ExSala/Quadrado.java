
package ExSala;

public class Quadrado extends Figuras {
    private double lado;
    
    public Quadrado(double lado){
        this.lado = lado;
    }
    
    public double areaCalculavel(){
        return lado * lado;
    }
    
    public double getLado(){
        return lado;
    }
    
    public void setLado(double lado){
        this.lado = lado;
    }
    
    
}
