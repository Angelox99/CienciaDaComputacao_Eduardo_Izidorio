
package ExSala;

public class Figuras {
    
    public double areaCalculavel(){
        return 0;
    }
    
}
