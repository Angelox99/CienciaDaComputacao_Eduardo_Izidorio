
package ExSala;

public class Calculdora {
    public static void main(String[] args) {
        Quadrado q = new Quadrado(2.0);
        Retangulo r = new Retangulo(2.0, 4.0);
        
        System.out.println(q.areaCalculavel());
        System.out.println(r.areaCalculavel());
    }
           
}
