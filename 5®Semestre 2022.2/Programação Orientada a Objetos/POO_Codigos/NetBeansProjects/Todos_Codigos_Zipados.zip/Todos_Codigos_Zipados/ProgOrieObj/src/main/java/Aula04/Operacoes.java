
package Aula04;

public class Operacoes {
    public static void main(String[] args){
        Calculadora calculo = new Calculadora();
        System.out.println("-----------------------------------");
        System.out.println("calculadora soma e multiplicação");
        System.out.println("-----------------------------------");
        System.out.println("Soma");
        System.out.println(calculo.somar(4, 3));
        System.out.println(calculo.somar(3, 7, 1));
        System.out.println(calculo.somar(4, 3, 9, 2));
        System.out.println("-----------------------------------");
    
        System.out.println("Multiplicação");
        System.out.println(calculo.mult(3, 2));
        System.out.println(calculo.mult(2, 4, 6));
        System.out.println(calculo.mult(3, 5, 7, 9));
        System.out.println("-----------------------------------");
    }
}
