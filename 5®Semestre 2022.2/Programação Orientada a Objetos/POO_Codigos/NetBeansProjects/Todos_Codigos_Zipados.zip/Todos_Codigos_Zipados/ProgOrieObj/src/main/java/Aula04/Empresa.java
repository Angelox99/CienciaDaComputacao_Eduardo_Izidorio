
package Aula04;

public class Empresa {
    funcionario[] empregados = new funcionario[10];
    String cnpj;
    String nome;
    String telefone;
    int posicao = 0;
    
    void mostraEmpresa()
    {
        System.out.println("\n\t\tEMPRESA\n");
        System.out.println("Nome : "+this.nome);
        System.out.println("CNPJ : "+this.cnpj);
        System.out.println("Telefone : "+this.telefone);
    }
    
    void adiciona(funcionario empregado){
        if(this.posicao < 10){
        this.empregados[this.posicao] = empregado;
        this.posicao++;
    }
   }
    
    void mostraFuncionarios(){
    for(int i = 0; i < this.empregados.length; i++){
        System.out.println("Funcionario " +i+ "\n");
        System.out.println("Nome "+i+": "+this.empregados[i].nome);
        System.out.println("Salario "+i+": "+this.empregados[i].salario);
        System.out.println("Departamento "+"F"+i+": "+this.empregados[i].departamento);
        }
    }
    void checkFuncionario(){
        for(int i = 0; i < this.empregados.length; i++){
            if (this.empregados[i].salario > 0){
                System.out.println("Funcionario"+i+" Faz parte da EMPRESA");
            }
            else{
                System.out.println("Funcionario"+i+" Nao faz parte da EMPRESA");
            }
        }
    }
}
