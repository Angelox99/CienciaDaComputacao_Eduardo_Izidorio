
package Aula04;

public class Data {
    int dia;
    int mes;
    int ano;
    
    public void formatadata(){
        System.out.print("Data:");
        System.out.println(dia + "/" + mes + "/" + ano);
    }
    
}
