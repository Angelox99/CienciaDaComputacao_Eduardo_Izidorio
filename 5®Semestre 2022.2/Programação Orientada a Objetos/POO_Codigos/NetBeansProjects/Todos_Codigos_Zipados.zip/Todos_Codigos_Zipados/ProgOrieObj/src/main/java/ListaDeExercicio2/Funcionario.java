
package Aula04;

public class Funcionario {
    String nome;
    String departamento;
    double salario;
    String RG;
    Data DatadeEntrada = new Data();
    //String data
    public void aumento(double valor){
           this.salario = this.salario + valor;
    }
    
    public double anual(){
        return this.salario * 12;
    }
    public void mostra(){
        
        System.out.println("Nome:" + this.nome);
        System.out.println("RG:" + this.RG);
        //System.out.println("Data: "+this.dataDeEntrData);
        this.DatadeEntrada.formatadata();
        System.out.println("Departamento:" + this.departamento);
        System.out.println("Salario:" + this.salario);
        System.out.println("Anual:" + this.anual());
        System.out.println("");
    }
}