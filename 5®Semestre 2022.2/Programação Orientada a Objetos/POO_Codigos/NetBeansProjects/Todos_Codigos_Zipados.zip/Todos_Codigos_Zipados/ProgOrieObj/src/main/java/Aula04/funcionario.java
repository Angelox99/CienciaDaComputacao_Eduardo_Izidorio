
package Aula04;

public class funcionario {
    String nome;
    String departamento;
    double salario;
    String RG;
    data DatadeEntrada = new data();
    //String data
    public void aumento(double valor){
           this.salario = this.salario + valor;
    }
    
    public double anual(){
        return this.salario * 12;
    }
    public void mostra(){
        
        System.out.println("Nome:" + this.nome);
        System.out.println("RG:" + this.RG);
        this.DatadeEntrada.formatadata();
        System.out.println("Departamento:" + this.departamento);
        System.out.println("Salario:" + this.salario);
        System.out.println("Salario Anual:" + this.anual());
        System.out.println("");
    }
}
