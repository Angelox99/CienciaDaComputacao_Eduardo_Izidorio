
package ExercicioAula05;

public class Empresa {
    private String nome;
    private String cnpj;
    private Funcionario[] empregados = new Funcionario[10];
    int posicao;
 
    //METODOS ESPECIAIS---------------------------------------------------------
    
    public String getNome(){
        return this.nome;
    }
    
    public void setNome(String n){
        this.nome = n;
    }
    public String getCnpj(){
        return this.cnpj;
    }
    
    public void setCnpj(String c){
        this.cnpj = c;
    }
    
    //METODOS-------------------------------------------------------------------
    
    public void add(Funcionario f){
        if(this.posicao < 10) {
            this.empregados[this.posicao] = f;
            this.posicao++;
        }
    }
    
    public void mostraFuncionarios(){
        for(int i = 0; i < this.empregados.length; i++){
            System.out.println("Funcionario " +i+ "\n");
            System.out.println("Nome "+i+": "+this.empregados[i].getNome());
            System.out.println("Salario "+i+": "+this.empregados[i].getSalario());
            System.out.println("Departamento "+"F"+i+": "+this.empregados[i].getDepartamento()+"\n");
        }
    } 
    
    void mostraEmpresa() {
        System.out.println("\n\t\tEMPRESA\n");
        System.out.println("Nome : "+this.getNome());
        System.out.println("CNPJ : "+this.getCnpj());
    }
    
    void checkFuncionario(){
        for(int i = 0; i < this.empregados.length; i++){
            if (this.empregados[i].getSalario() > 0){
                System.out.println("Funcionario"+i+" Esse funcionario faz parte da EMPRESA");
            }
            else{
                System.out.println("Funcionario"+i+" Esse fimcionario nao faz parte da EMPRESA");
            }
        }
    }
}
