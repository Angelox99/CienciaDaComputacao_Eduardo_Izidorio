
package Aula04;

public class Calculadora {
    public double somar(double... valores){
        double s = 0;
        for(double valor: valores){
            s+=valor;
        }
        //for(int i =0; i < valores.length; i++){
        //  s+=valores[i];
        //}
        return s;
    }
    public double mult(double... valores){
        double s = 1;
        for(double valor: valores){
            s*=valor;
        }
        return s;
    }
//    double soma(double a, double b){
//        return a+b;
//    }
//    double soma(double a, double b, double c){
//        return a+b+c;
//    }
//    double soma(double a, double b, double c, double d){
//        return a+b+c+d;
//    }
//    double mult(double a, double b){
//        return a*b;
//    }
//    double mult(double a, double b, double c){
//        return a*b*c;
//    }
//    double mult(double a, double b, double c, double d){
//        return a*b*c*d;
//    }
}
