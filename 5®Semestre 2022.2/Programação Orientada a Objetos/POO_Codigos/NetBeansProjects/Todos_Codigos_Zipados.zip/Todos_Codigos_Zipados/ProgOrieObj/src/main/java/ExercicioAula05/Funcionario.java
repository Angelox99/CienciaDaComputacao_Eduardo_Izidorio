
package ExercicioAula05;

public class Funcionario {
    private String nome;
    private String departamento;
    private double salario;
    private String rg;
    private static int indentificador;
    private int id;
    
    Data dataEntrada = new Data();
    

    
// CONSTRUTORES-----------------------------------------------------------------    
    
    //contrutor para receber o nome do funcionario na criação do objeto
    public Funcionario(String n){
        this.nome = n;
        this.id = ++Funcionario.indentificador; 
    }
    //contrutor vazio para receber opcionalmente na criação do objeto
    public Funcionario(){
        this.id = ++Funcionario.indentificador;  
    }
    
// METODOS ESPECIAIS------------------------------------------------------------
    
    public String getNome(){
        return this.nome;
    }
    
    public void setNome(String n){
        this.nome = n;
    }
    
    public String getDepartamento(){
        return this.departamento;
    }
    
    public void setDepartamento(String d){
        this.departamento = d;
    }
    
    public double getSalario(){
        return this.salario;
    }
    
    public void setSalario(double s){
        this.salario = s;
    }
    
    public String getRg(){
      return this.rg;
    }
   
    public void setRg(String r){
       this.rg = r;
    }
    
    public int getId(){
        return id;
    }
    
    
//    public int getIdentificador(){
//        return this.indentificador;
//    }
   
    

//METODOS-----------------------------------------------------------------------
    
    private void recebeAumento(double valor){
        this.salario += valor;
    }
    private double calculaGanhaAnual(){
        return this.salario * 12;
    }
    
    public void mostra(){
        System.out.println("\nId do funcionario: "+ this.getId());
        System.out.println("\nNome: "+ this.getNome());
        System.out.println("Departamento: " + this.getDepartamento());
        System.out.println("RG: "+ this.getRg());
        System.out.println("Salário: R$"+ this.getSalario());
    
        //System.out.println("\nGanho Anual: R$"+calculaGanhaAnual());
        //System.out.println("\nDataEntrada: ");
        //System.out.println(this.dataEntrada); printar a data
        //this.dataEntrada.formatData(); //printar a data formatada
    }
}
