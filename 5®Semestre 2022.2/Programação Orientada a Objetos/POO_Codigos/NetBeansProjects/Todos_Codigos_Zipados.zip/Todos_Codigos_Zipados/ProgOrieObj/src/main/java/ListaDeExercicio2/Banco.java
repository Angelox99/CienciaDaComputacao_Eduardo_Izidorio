
package Aula04;

public class Banco {
    public static void main(String[] args) throws Exception {
        Funcionario e1;
        e1 = new Funcionario();
        
        //Funcionário 1
        e1.nome = "Menezes";
        e1.RG = "894766-9";
        e1.DatadeEntrada.dia = 15;
        e1.DatadeEntrada.mes = 12;
        e1.DatadeEntrada.ano = 1990;
        e1.departamento = "Administração";
        e1.salario = 2700;
        e1.aumento(200);
        e1.anual();
        
        //Funcionário 2
        Funcionario e2;
        e2 = new Funcionario();
        
        e2.nome = "Clotiude";
        e2.RG = "367476-0";
        e2.DatadeEntrada.dia = 20;
        e2.DatadeEntrada.mes = 12;
        e2.DatadeEntrada.ano = 1980;
        e2.departamento = "Banco de Dados";
        e2.salario = 2700;
        e2.aumento(200);
        e2.anual();
        
        
        //Printa os enderecos
        System.out.println("e1: "+e1);
        System.out.println("e2: "+e2);
        System.out.println("");
        
        //Sempre sera diferente, pois nao esta compara atributos e sim endereços.
        if(e1 == e2){
            System.out.println("São Iguais! \n" );
        } else {
            System.out.println("São Diferentes! \n");
        }
        
        System.out.println("e1");
        e1.mostra();
        System.out.println("e2");
        e2.mostra();
        
    }
}
