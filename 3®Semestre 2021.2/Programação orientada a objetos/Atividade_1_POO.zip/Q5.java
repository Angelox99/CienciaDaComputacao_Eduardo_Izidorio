package atividade03;

public class Q5 {
	
	public static void main(String[] args) {
		
		for(int i=1 ; i<=5 ; i++) {
			System.out.println(i * 3);
		}
	}

}
