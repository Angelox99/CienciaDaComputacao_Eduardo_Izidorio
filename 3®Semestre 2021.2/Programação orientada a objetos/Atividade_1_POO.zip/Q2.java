package atividade03;

import java.util.Scanner;

public class Q2 {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Digite um numero qualquer: ");
		double numero = sc.nextDouble();
		
		if(numero > 0) {
			double dobro = numero * 2;
			System.out.println("O dobro do numero �: " + dobro);
		}else {
			double quadrado = numero * numero;
			System.out.println("O numero ao quadrado �: " + quadrado);
		}
		
		sc.close();
	}

}
