package atividade03;

import java.util.Scanner;

public class Q4 {
	
public static void main(String[] args) { 
		
		int n = 0;
		int menor, maior;
		menor = maior = n;
		try (Scanner sc = new Scanner(System.in)) {
			do { 

			System.out.print("Digite um n�mero: "); 
			n = sc.nextInt(); 
			
			if (n < menor) {
				menor = n;
			}
			if (n > maior) {
				maior = n;
			}

			} while (n>0);
		} 
		
		System.out.println("Menor numero �: " + menor);
		System.out.println("Maior numero �: " + maior);
		
	} 

}


