package atividade03;

import java.util.Scanner;

public class Q6 {
	public static void main(String[] args) { 
		try (Scanner teclado = new Scanner(System.in)) {
			System.out.println("Digite um n�mero: "); 
			int n = teclado.nextInt(); 
			System.out.println("O n�mero digitado foi: " + n + "."); 
			System.out.println("Os n�meros �mpares at� " + n + " s�o: "); 
			
			for (int r=1; r<=n; r++) { 
				if (r%2!=0) { 
					System.out.print(r + " "); 

				} 

			}
		}
	
	}

}
