package atividade03;

import java.util.Scanner;

public class Q3 {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Digite o valor do seu sal�rio:R$ ");
		double salario = sc.nextDouble();
		System.out.print("Digite o valor da presta��o:R$ ");
		double prestacao = sc.nextDouble();
		
		if(prestacao > salario * 20 / 100) {
			System.out.println("Emprestimo n�o concedido.");
		}else {
			System.out.println("Emprestimo concedido.");
		}
		
		sc.close();
	}
	
}
