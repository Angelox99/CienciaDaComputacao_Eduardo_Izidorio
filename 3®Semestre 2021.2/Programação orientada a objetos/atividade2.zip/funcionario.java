package att2;

public class funcionario {
	//atributos da minha classe 
	private String nome;
	private String cpf;
	private String rg;
	private String data_Entrada;
	private String cargo;
	private String departamento;
	private double salario_Atual;
	private double salario_Anual;
	
		
		public void setNome(String nome)
		{
			this.nome = nome;
		}
		
		public void setCPF(String cpf)
		{
			this.cpf = cpf;
		}
		
		public void setRG(String rg)
		{
			this.rg = rg;
		}
		
		public void setData_Entrada(String data_Entrada)
		{
			this.data_Entrada = data_Entrada;
		}
		
		public void setDepartamento(String departamento)
		{
			this.departamento = departamento;
		}
		
		public void setCargo(String cargo)
		{
			this.cargo = cargo;
		}
		public void setSalario_Atual(double salario_Atual)
		{
			this.salario_Atual = salario_Atual;
		}
		
		public void setSalario_Anual(double salario_Anual)
		{
			this.salario_Anual = salario_Anual;
		}
/*******************/			
		public getNome(String nome)
		{
			return this.nome;
		}
		
		public String getCPF(String cpf)
		{
			return this.cpf;
		}

}


